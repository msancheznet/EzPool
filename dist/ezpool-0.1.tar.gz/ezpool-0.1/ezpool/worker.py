import Pyro4
import argparse
from .objects import BaseWorker, run_object

def fib(n):
	return 1 if n<2 else fib(n-1)+fib(n-2)

class ArgWorker(BaseWorker):
	@staticmethod
	def parse_args(args=None):
		return _get_args_parser().parse_args(args)

class EchoWorker(ArgWorker):
	def run(self, inp):
		return inp

class FibWorker(ArgWorker):
	def run(self,n):
		return fib(n)
		
def _get_args_parser():
	parser = argparse.ArgumentParser()
	parser.add_argument('--uri', '-u', nargs='?', default='', help='Job manager URI', type=str)
	parser.add_argument('--address','-a', nargs='?', default='localhost', help='IP adress', type=str)
	parser.add_argument('--port','-p', nargs='?', default=21000, help='TCP port', type=int)
	parser.add_argument('--name','-n', nargs='?', default='worker', help='Worker name', type=str)
	parser.add_argument('--msg','-m', nargs='?', default='Worker ready to proces jobs:', help='Message to display when object is started', type=str)
	#parser.add_argument('--nserver','-ns', action='store_true', help='Run name server')
	return parser

if __name__ == '__main__':
	run_object(FibWorker)