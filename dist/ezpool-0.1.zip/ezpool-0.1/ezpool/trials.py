from scheduler import _get_args_parser, JobManager
from objects import run_object, spawn_object
from proxies import EzProxy, connect_to
from worker import EchoWorker

class EzPool(object):
	""" This class provides an unique interface to run a set of tasks in serial, parallel or
		distributed mode. To run tasks in through this Pool, use the ``map`` function.

		**Serial Mode**: All tasks are run in order in one core:
		
		.. code-block:: python
			:linenos:

			tasks = list(range(30))
			with Pool(mode='serial') as pool:
				results = pool.map(tasks)

		**Parallel Mode**:All tasks are run in multiple cores of one machine (no order is preserved):

		.. code-block:: python
			:linenos:

			tasks = list(range(30))
			with Pool(mode='parallel', ncores=5) as pool:
				results = pool.map(tasks)

		**Distributed Mode**:All tasks are run in multiple cores of one or multiple machines (no order is preserved):

		.. code-block:: python
			:linenos:

			from workers import EchoWorker

			tasks   = list(range(30))
			workers = ('PYRO:worker@localhost:21000', 'PYRO:worker@remote:21000')
			worker_type = EchoWorker
			with Pool(mode='parallel', workers=workers, worker_type=worker_type) as pool:
				results = pool.map(tasks)

		The distributed mode relies on the JobManager object to schedule tasks across workers. In
		general, you will run the JobManager on your local machine, but that is not required. Also,
		the JobManager is set up so that you can add/remove workers while computations are going on,
		but removing a worker that is currently running a task will result in that task not being
		evaluated.

		.. Tip:: The `map` function of this pool is blocking, i.e. the current thread will wait until
				 all the results are available before proceeding.
		.. Tip:: You could use the distributed mode and have the Job Manager and the workers live in
				 the localhost. This would essentially be equivalent to the `parallel` mode, but will
				 incur in more overhead, so it is not recommended.
		.. Tip:: For testing purposes, you can use the distributed mode without any parameters for the
				 `map` function. This will just spawn new processes in the local machine for the job manager
				 and workers, and clean them after the jobs have been run.
	"""
	def __init__(self, mode='distributed'):
		if mode not in ['serial', 'parallel', 'distributed']:
			raise ValueError('Pool mode is set to {}. Allowed values are "serial", "parallel","distributed"')
		self._mode  = mode
		self._procs = {}

	def __enter__(self):
		return self

	def __exit__(self, exc_type, exc_val, exc_tb):
		self.shutdown()
		return False	# Reraise the exception

	def shutdown(self):
		for uri in self._procs:
			proxy = EzProxy(uri)
			if proxy.connected:
				proxy.shutdown()
				proxy.close()
			self._procs[uri].terminate()
		self._procs.clear()

	def map(self, tasks, job_mgr='PYRO:jobmgr@localhost:20000', workers=('PYRO:worker@localhost:21000',), worker_type=EchoWorker):
		if self._mode == 'serial':
			return self._submit_serial(tasks)
		elif self._mode == 'parallel':
			return self._submit_parallel(tasks)
		else:
			return self._submit_distributed(tasks, job_mgr, workers, worker_type)

	def _submit_serial(self, tasks):
		raise NotImplementedError()

	def _submit_parallel(self, tasks):
		raise NotImplementedError()

	def _submit_distributed(self, tasks, job_mgr, workers, worker_type=EchoWorker):
		try:
			job_mgr_p = self._new_proxy(job_mgr, JobManager)
			for worker in workers:
				worker_p = self._new_proxy(worker, worker_type)
				job_mgr_p.add_worker(worker)
				worker_p.close()
		except Exception as e:
			self.shutdown()
			raise e

		res = job_mgr_p.map(tasks)
		job_mgr_p.close()

		return res

	def _new_proxy(self, uri, obj_type):
		proxy, proc = connect_to(uri, obj_type)
		if proc is not None:
			self._procs[uri] = proc
		return proxy

if __name__ == '__main__':
	workers = ('PYRO:worker@localhost:21000','PYRO:worker@localhost:21001')

	with EzPool() as p:
		print(p.map([i for i in range(500)],workers=workers))